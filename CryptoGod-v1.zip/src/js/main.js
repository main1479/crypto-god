const navButton = document.querySelector('.nav__button');
const navTriggers = document.querySelectorAll('.menu__trigger');
const nav = document.querySelector('.nav');

navTriggers.forEach((btn) => {
	btn.addEventListener('click', () => {
		nav.classList.toggle('active');
		navButton.classList.toggle('active');
	});
});
